require File.dirname(__FILE__) + '/lib/sphinx'
